import pandas as pd
import numpy as np
from matplotlib import pyplot as plt

#Create your df here: